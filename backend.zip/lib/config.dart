class AppConfig {
  // static const String baseUrl = "http://192.168.1.36:5000"; // 🔁 Replace with your IP
  static const String baseUrl = "http://172.20.10.4:5000"; // 🔁 Replace with your IP

}
